'use strict';
angular.module('ArulInstitute')

//####################################
//####################################
//  CONTROLLER DEFINITIONS
//####################################
//####################################

    .controller('AppCtrl', AppCtrl);


//####################################
//####################################
//  APP CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name AppCtrl
 * @description
 * The main controller for the app (only applies to those screens that have the toolbar at the bottom of them)
 */


function AppCtrl() {

    console.log('Init App Controller');

}

