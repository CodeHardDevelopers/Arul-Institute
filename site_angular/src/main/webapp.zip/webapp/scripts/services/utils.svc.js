'use strict';
angular.module('ChanelInspire')

  .factory('Utils', Utils);



//####################################
//####################################
//  GENERAL UTILS SERVICE
//####################################
//####################################

/**
 * @ngdoc service
 * @name Utils
 * @description
 * Service for global data manipulation needs
 */

function Utils() {

  var service = {
    dedupeArray: dedupeArray,
    trimId: trimId,
    isEmptyObject: isEmptyObject,
    escapeXMLString: escapeXMLString
  }

  return service;

//####################################
//  DEDUPE ARRAY
//####################################

  /**
   * @ngdoc function
   * @name dedupeArray
   * @description
   * Dedupe an array by id
   * @param {array} array The array you want to dedupe
   * @returns {array} The deduped array
   */

  function dedupeArray(array) {

    var dedupeObj = {};
    var itemKey;
    for (var i = 0; i < array.length; i++) {
      //make a key of the object's own keys and values
      if (typeof array[i] === 'object') {
        itemKey = array[i].id;
        dedupeObj[itemKey] = array[i];
      } else {
        dedupeObj[array[i]] = true;
      }
    }
    array = [];
    for (var key in dedupeObj) {
      //rebuild the object in the returned array
      if (typeof dedupeObj[key] === 'object') {
        array.push(dedupeObj[key]);
      }
      else {
        array.push(key);
      }
    }
    return array;

  }


//####################################
//  TRIM ID
//####################################


  /**
   * @ngdoc function
   * @name trimId
   * @description
   * Method to trim wacky id
   * @param {string} id The long namespaced id you want to trim to just a 36 char guid
   * @returns {string} The trimmed id
   */

  function trimId(id) {
    if(id.length == 36){
      return id;
    }else{
      return id.slice(-36);
    }
  }

//####################################
//  IS EMPTY OBJECT
//####################################


  /**
   * @ngdoc function
   * @name isEmptyObject
   * @description
   * Method to check whether the given obj has any custom properties set on it.
   * @param {object} obj Object to be checked
   * @returns {boolean} returns true if the object is empty. 
   */

  function isEmptyObject(obj) {
    for(var prop in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, prop)) {
        return false;
      }
    }
    return true;
  }


//####################################
//  ESCAPE XML STRING
//####################################


  /**
   * @ngdoc function
   * @name escapeXMLString
   * @description
   * Method to convert a normal string to valid string for xml document.
   * @param {string} value - String to be converted
   * @returns {string} returns escaped string 
   */

  function escapeXMLString(value) {
    if(value){
      return value && value.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&apos;');
    }else{
      return '';
    }

  }



}
