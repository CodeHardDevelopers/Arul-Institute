'use strict';

var app = {
  initialize: function () {
    angular.element(document).ready(function () {      
      angular.bootstrap(document.body, ['ArulInstitute']);      
      console.log('Bootstrapping Angular');
    });
  }
};




