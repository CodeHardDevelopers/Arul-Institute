'use strict';

angular.module('ArulInstitute')
    .run(run);

/**
 * @ngdoc function
 * @name run
 * @description
 * Fires up the app
 */


function run($rootScope) {

    $rootScope.$on('$stateChangeSuccess',
    function(event, toState, toParams, fromState, fromParams){
        console.log("state change success");
     });


    console.log('App Run');
}
