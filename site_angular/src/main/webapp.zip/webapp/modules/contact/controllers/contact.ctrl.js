'use strict';


angular.module('ArulInstitute.contact',[])

    .controller('ContactCtrl', ContactCtrl);

//####################################
//####################################
//  Contact CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name ContactCtrl
 * @description
 * The controller for contact us section
 */

function ContactCtrl ($scope, $state, $stateParams) {
	
    //####################################
    //  SCOPE VARIABLES
    //####################################
    

	//####################################
    //  SCOPE FUNCTIONS
    //####################################


    console.log('ContactCtrl: came inside about us controller');
}