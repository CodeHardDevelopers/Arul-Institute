'use strict';


angular.module('ArulInstitute.instructions',[])

    .controller('InstructionsCtrl', InstructionsCtrl);

//####################################
//####################################
//  Instructions CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name InstructionsCtrl
 * @description
 * The controller for Instructions section
 */

function InstructionsCtrl ($scope, $state, $stateParams) {
	
    //####################################
    //  SCOPE VARIABLES
    //####################################
    

	//####################################
    //  SCOPE FUNCTIONS
    //####################################


    console.log('InstructionsCtrl: came inside instructions controller');
}