'use strict';


angular.module('ArulInstitute.home')

    .controller('AboutCtrl', AboutCtrl);

//####################################
//####################################
//  ABOUT CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name AboutCtrl
 * @description
 * The controller for About us section
 */

function AboutCtrl ($scope, $state, $stateParams) {
	
    //####################################
    //  SCOPE VARIABLES
    //####################################
    

	//####################################
    //  SCOPE FUNCTIONS
    //####################################


    console.log('AboutCtrl: came inside about us controller');

    
}