'use strict';


angular.module('ArulInstitute.home')

    .controller('IntroCtrl', IntroCtrl);

//####################################
//####################################
//  INTRO CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name IntroCtrl
 * @description
 * The controller for About us section
 */

function IntroCtrl ($scope, $state, $stateParams) {
	
    //####################################
    //  SCOPE VARIABLES
    //####################################
    

	//####################################
    //  SCOPE FUNCTIONS
    //####################################


    console.log('IntroCtrl: came inside about us controller');
}