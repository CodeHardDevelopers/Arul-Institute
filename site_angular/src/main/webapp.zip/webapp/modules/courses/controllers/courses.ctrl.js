'use strict';


angular.module('ArulInstitute.courses',[])

    .controller('CoursesCtrl', CoursesCtrl);

//####################################
//####################################
//  Courses CONTROLLER
//####################################
//####################################

/**
 * @ngdoc function
 * @name CoursesCtrl
 * @description
 * The controller for  courses section
 */

function CoursesCtrl ($scope, $state, $stateParams) {
	
    //####################################
    //  SCOPE VARIABLES
    //####################################
    

	//####################################
    //  SCOPE FUNCTIONS
    //####################################


    console.log('CoursesCtrl: came inside courses controller');
}